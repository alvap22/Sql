    <?php
        $servidor="localhost";
        $usuario="alvaro";
        $senha="alvaro221006";
        $banco="alvaro";

        $mysqli = new mysqli($servidor, $usuario,  $senha, $banco  );
        if ($mysqli->connect_errno){
        echo "Não deu certo" . $mysqli->connect_error;
        exit();        

        }
    ?>