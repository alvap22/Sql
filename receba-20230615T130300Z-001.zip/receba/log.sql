-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 10-Ago-2022 às 13:19
-- Versão do servidor: 5.7.36
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `site123`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE IF NOT EXISTS `log` (
  `id_senha` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(500) COLLATE utf8_bin NOT NULL,
  `senha` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id_senha`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `log`
--

INSERT INTO `log` (`id_senha`, `login`, `senha`) VALUES
(1, 'asdad', '$2y$10$jYf6/kZvi5wg/71.8WRtlu6qZMtTPp5jjn/ZEwMC98NEgHscLwLWG'),
(2, 'abc', '$2y$10$4SbZljxGkzYwvPI/xMGlc.IvT9Pzh/zfDZNNb27eKFEHRhbmsz/AK'),
(3, 'igor', '$2y$10$xLN85QIbnds65wLWskIBBOT9iOVa72wpvAbgY0WJ8jy2SWYBEd3/S'),
(4, 'marcelo', '$2y$10$MYupLsNEWlRsOIqJ5gvjW.gb7RR3ypHi8n4amTAnnRw6ojg6kgfPG');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
