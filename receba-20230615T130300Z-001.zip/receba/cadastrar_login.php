<?php
        include("conexao.php");
    if(isset($_POST['bt_login'])){
      
      $login = $_POST['bt_login'];
      $senha = $_POST['bt_senha'];

      $senha_nova = password_hash(($senha),PASSWORD_DEFAULT);

      $mysqli -> query("INSERT INTO log (login, senha) values ('$login','$senha_nova')") or die ($mysqli->error);

      }

    ?>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <link rel="stylesheet" href="img\meuestilo.css">
        <title>tela de login</title>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="login.php">Entrar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="consul.php">Mensagens</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
      <h1>tela de login</h1>
        <div class="container col-19 col-md9" id="form-container">
           <div class="row align-items-center gx-5">
             <div class="col=md-6 order-md-2">
              <h1>tela de login</h1>
                <form action="" method="post">
                  <div class="form-floating mb-3">
                  <input class="form-control" type="text" placeholder="digite a seu login" name="bt_login">
                  <label class="form-label" for="login">login</label>
                   
                  </div>
                  <div class="form-floating mb-3">
                  <input class="form-control" type="password" placeholder="digite a sua senha" name="bt_senha">
                  <label class="form-label" for="senha">senha</label>
                    
                  </div>
                  
                  <button class="btn btn-primary" type="submit">Enviar arquivo</button>
            <button class="btn btn-danger" type="reset">cancelar</button>
            
                    </form>
                </div>
                <div class="col-md-6 order-md-1">
                  <div class="col-12">
                    <img src="img\login.svg" alt="" class="img-fluid">
                  </div>
              </div>
           </div>
       </div>
       <script src="Jquery/jquery-3.6.0.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>  
    </body>
    </html>