    <?php
        include("conexao.php");
        if(isset($_POST['bt_name'])){
            $nome = $_POST['bt_name'];
            if(isset($_FILES['bt_arquivo'])){
                $arquivo = $_FILES['bt_arquivo'];
                if($arquivo['size']>15000000){
                    die("Arquivo muito graudo!!!! maximo de 15mb");
                }
                if($arquivo['error']){
                    die("Falha ao enviar arquivo");
                }
                $recebidos ="recebidos/";
                $nome_arquivo=$arquivo['name'];
                $novo_nome_arquivo = uniqid();

            $extensao = strtolower(pathinfo($nome_arquivo, PATHINFO_EXTENSION));

            $caminho = $recebidos . $novo_nome_arquivo . "." . $extensao;

            if($extensao !="jpg"){
                die("Tipo de arquivo não aceito");
                }

            $deucerto = move_uploaded_file($arquivo["tmp_name"],$caminho);

            if($deucerto){
                $mysqli -> query("INSERT INTO tabela_receber (nome, arquivo_receber) values ('$nome','$caminho')") or die ($mysqli->error);
                }
            }            
        }
    ?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

        <title>Formulario - Receber</title>
    </head>
    <body>
    <nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Entrar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="consultar.php">Mensagens</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
        <div class="container">
        <h1>Formulario - Receber</h1>   
        <form action="" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label" for="">Nome:</label>
                <input class="form-control" type="text" name="bt_name" required> 
                <div class="form-text"> *insira o nome completo.</div>
            </div>
            <label class="form-label" for="bt_arquivo" >Selecione um arquivo</label>
            <input class="form-control" type="file" name="bt_arquivo" required>
            <div class="form-text"> *Insirir apenas arquivos .jpg</div>
            <br></br>
            <button class="btn btn-primary" type="submit">Enviar arquivo</button>
            <button class="btn btn-danger" type="reset">Limpar</button>
            

        </form> 
        </div> 
        <script src="Jquery/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>  
    </body>
</html>