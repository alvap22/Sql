<?php
        include("conexao.php");
        $login = $_POST["bt_login"];
        $senha = $_POST["bt_senha"];
       

        if(empty($_POST["login"])){
            echo "<p>Prencha o campo nome</p>";
        }
        if(empty($_POST["senha"])){
            echo "<p>Prencha o campo nome</p>";
        }else{?>

    <?php
        }

    
        
        
        echo $login. "<br>";
        echo $senha. "<br>";

        $sql = "INSERT INTO  login (login, senha,) VALUES ('$login','$senha')";
        $ale = $mysqli->query($sql) or die ($mysqli->error);
        
    ?>

   
    <!DOCTYPE html>
        <html lang="en">
        <head>
            <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="cot.css">
            <title>Info</title>
        </head>
        <body>
            <div  class="container">
                <a type="button" class="btn btn-success" href="consul.php"> Voltar</a>
            </div>
        </body> 
        </html>