
<?php
    include("conexao.php");

    $sql_mensagens = "SELECT * FROM  mensagem ";
    $consulta_mensagens = $mysqli->query($sql_mensagens) or die($mysqli->error);
    $quantidade_mensagens = $consulta_mensagens->num_rows;
?>

<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
            <title>Document</title>
        </head>
        <body>
        <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button id="bt_tres" type="button " class="navbar-toggle collapse" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                </button>
                <a id="ssw" class="navbar-brand" href="desenhos.php">Mecanimais</a>
            </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active"><a id="personagens" href="conta.html">contato <span class="sr-only">(current)</span></a></li>
            </ul>
            <ul class="nav navbar-nav">
                <li class="active"><a id="personagens" href="centmens.php">Mensagem <span class="sr-only">(current)</span></a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Mensagem</th>
                    <th>Data</th>
                    <th>Ações</th>
                </thead>
                <tbody>
                <?php if ($quantidade_mensagens == 0 ){ ?>
                        <tr>
                            <td colspan="6">Nenhuma  mensagem encontrada</td>
                        </tr>
                    <?php
                        } else {
                            while ($mensagem = $consulta_mensagens -> fetch_assoc()){

                                $data = date ("d/m/Y H:i", strtotime ($mensagem['log']));
                    ?>
                    <tr>
                        <td> <?php echo $mensagem['id_mensagem']; ?> </td>
                        <td> <?php echo $mensagem['nome']; ?> </td>
                        <td> <?php echo $mensagem['email']; ?> </td>
                        <td> <?php echo $mensagem['mensagem']; ?> </td>
                        <td> <?php echo $data; ?> </td>
                        <td> 
                        <a class="btn btn-default" href="editar.php?id=<?php echo $mensagem['id_mensagem']; ?>" role="button"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Editar</a>
                                        <a class="btn btn-default" href="deletar.php?id=<?php echo $mensagem['id_mensagem']; ?>" role="button"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Deletar</a>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script> 
        <script src="bootstrap\js\bootstrap.js"></script>
        </body>
    </html>