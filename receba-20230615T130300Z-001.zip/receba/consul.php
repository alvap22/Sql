<?php
    include("conexao.php");

    $sql_mensagens = "SELECT * FROM log ";
    $consulta_mensagens = $mysqli->query($sql_mensagens) or die($mysqli->error);
    $quantidade_mensagens = $consulta_mensagens->num_rows;
?>

<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
            <title>Document</title>
        </head>
        <body>
        <nav class="navbar navbar-expand-lg bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="login.php">Entrar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="consul.php">Mensagens</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <th>ID</th>
                    <th>Login</th>
                    <th>senha</th>
                </thead>
                <tbody>
                <?php if ($quantidade_mensagens == 0 ){ ?>
                        <tr>
                            <td colspan="6">Nenhuma  mensagem encontrada</td>
                        </tr>
                    <?php
                        } else {
                            while ($mensagem = $consulta_mensagens -> fetch_assoc()){
                    ?>
                    <tr>
                        <td> <?php echo $mensagem['id_senha']; ?> </td>
                        <td> <?php echo $mensagem['login']; ?> </td>
                        <td> <?php echo $mensagem['senha']; ?> </td>
                    </tr>
                    <?php 
                    }
                    ?>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script> 
    <script src="Jquery/jquery-3.6.0.min.js"></script>
        </body>
    </html>