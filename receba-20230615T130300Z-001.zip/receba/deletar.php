<?php
    include("conexao.php");

    if(isset($_GET['id'])){

        $id_mensagem = intval($_GET['id']);

        $sqli_mensagens = "SELECT * FROM tabela_receber WHERE id_receber = '$id_mensagem'";
        

        $consulta_mensagens = $mysqli->query( $sqli_mensagens) or die($mysqli->error);

        $mensagem = $consulta_mensagens -> fetch_assoc(); 

        $data = date("d/m/Y H:i", strtotime($mensagem['data']));  
    }
     if(count($_POST) > 0) {



        $deubl = $mysqli->query($sqli_mensagens) or die ($mysqli->error);
        
    }
    
   

   

    if(isset($_POST['confirmar'])){ //Se existir $_POST['confirmar] faça

        $sql_deletar = "DELETE FROM tabela_receber WHERE  id_receber = '$id_mensagem'";

        $deucerto = $mysqli->query($sql_deletar) or die ($mysqli->error);   
        //unset($_GET);
    }

    //var_dump($mensagem);
?>

<!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <title>Deletar Mensagem</title>
    </head>
    <body>
     <nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Entrar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="consultar.php">Mensagens</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
        <div class="container">
            <h1>Tem certeza que deseja deletar esta mensagem?</h1>

            <div class="table-responsive">
                <table class="table table-hover">
                <thead>
                        <th>Id</th>
                        <th>Nome</th>
                        <th>Caminho</th>
                        <th>Data</th>
                        <th>Ações</th>
                    </thead>
                    <tbody>
                        <tr>
                            <?php
                                if (isset($deucerto)){ ?> 
                                    <td><?php echo "Mensagem apagado"; ?></td>                           
                        
                            <?php } else{?>

                                <td> <?php echo $mensagem['id_receber']; ?> </td>
                        <td> <?php echo $mensagem['nome']; ?> </td>
                        <td> <?php echo "<a target= _blak href=" .$mensagem['arquivo_receber'].">".$mensagem['arquivo_receber']. "</a>"; ?> </td>
                        <td> <?php echo $data; ?> </td>                         
                            <?php }?>
                        </tr> 
                    </tbody>
                </table>
            </div>

            <form action="" method="post">
                <button name="confirmar" value="1" class="btn btn-danger">Sim</button>
                <a href="consultar.php" class="btn btn-default">Não</a>
            </form>

            <?php
            if (isset($deubl)){ ?>
                
                <h1>As informações foram apagadas com sucesso. </h1>
                <p><a href="consultar.php">Clique</a> aqui para voltar.</p>
                
                
            <?php
           // header("Refresh:1");
            //die();
        } ?>
             </div>  
        <script src="Jquery/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>  
    </body>
</html>